-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 23, 2021 at 08:54 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tp`
--

-- --------------------------------------------------------

--
-- Table structure for table `adh`
--

CREATE TABLE IF NOT EXISTS `adh` (
  `AID` int(11) NOT NULL AUTO_INCREMENT,
  `gphoto` text NOT NULL,
  PRIMARY KEY (`AID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `adh`
--

INSERT INTO `adh` (`AID`, `gphoto`) VALUES
(4, 'IMG-6079b2a9ed6e46.51663785.jfif'),
(5, 'IMG-6079b2b25122f8.47658837.png');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE IF NOT EXISTS `bookings` (
  `bid` int(50) NOT NULL AUTO_INCREMENT,
  `dest` varchar(250) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`bid`, `dest`, `date`) VALUES
(1, 'paris', '2021-04-06'),
(2, 'paris', '2021-04-06'),
(8, 'dubai', '2021-04-29'),
(10, 'france', '2021-05-06'),
(11, 'Germany', '2021-05-24');

-- --------------------------------------------------------

--
-- Table structure for table `cal`
--

CREATE TABLE IF NOT EXISTS `cal` (
  `cid` int(5) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `mon` varchar(25) NOT NULL,
  `week` varchar(50) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cal`
--


-- --------------------------------------------------------

--
-- Table structure for table `doc`
--

CREATE TABLE IF NOT EXISTS `doc` (
  `gid` int(50) NOT NULL AUTO_INCREMENT,
  `photo` varchar(500) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `doc`
--


-- --------------------------------------------------------

--
-- Table structure for table `dr`
--

CREATE TABLE IF NOT EXISTS `dr` (
  `did` int(50) NOT NULL AUTO_INCREMENT,
  `gphoto` text NOT NULL,
  PRIMARY KEY (`did`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `dr`
--

INSERT INTO `dr` (`did`, `gphoto`) VALUES
(1, 'IMG-6079afe2944691.50444770.jfif'),
(2, 'IMG-6079afec50eaf0.62105934.jfif'),
(3, 'IMG-608288037675c3.12607862.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `galid` int(20) NOT NULL AUTO_INCREMENT,
  `gphoto` text NOT NULL,
  PRIMARY KEY (`galid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`galid`, `gphoto`) VALUES
(68, 'IMG-60689b2d9b0468.64902429.jfif'),
(69, 'IMG-60689b3caba0d9.71274004.jfif'),
(70, 'IMG-60689c1e6aa0a1.44678740.jfif'),
(71, 'IMG-60689c299d7551.93931699.jfif'),
(72, 'IMG-60689c8f045ab4.84612017.jfif'),
(73, 'IMG-60689c98b2aa91.92484114.jfif'),
(74, 'IMG-60689ca3523e32.49508234.jfif'),
(75, 'IMG-60689cb7419b94.31980337.jfif'),
(76, 'IMG-60689cc37286c9.76220604.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `hid` int(20) NOT NULL AUTO_INCREMENT,
  `tname` varchar(200) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `history`
--


-- --------------------------------------------------------

--
-- Table structure for table `oth`
--

CREATE TABLE IF NOT EXISTS `oth` (
  `oid` int(50) NOT NULL AUTO_INCREMENT,
  `gphoto` text NOT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `oth`
--

INSERT INTO `oth` (`oid`, `gphoto`) VALUES
(1, 'IMG-6079b260a076a0.50148433.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `packing`
--

CREATE TABLE IF NOT EXISTS `packing` (
  `pid` int(50) NOT NULL AUTO_INCREMENT,
  `items` varchar(250) NOT NULL,
  `no.` int(100) NOT NULL,
  `type` varchar(250) NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `packing`
--


-- --------------------------------------------------------

--
-- Table structure for table `pas`
--

CREATE TABLE IF NOT EXISTS `pas` (
  `pid` int(50) NOT NULL AUTO_INCREMENT,
  `gphoto` text NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pas`
--

INSERT INTO `pas` (`pid`, `gphoto`) VALUES
(1, 'IMG-6079b154a9dff6.18451834.jfif'),
(2, 'IMG-6079b1670e80a1.60654677.jfif');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(10) NOT NULL,
  `uid` int(5) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `pass`, `uid`) VALUES
('prarthana', 'prarthanapatel2001@gmail.com', 'Abcd17', 1),
('', 'abc@gmail.com', 'oojd', 2),
('parul', 'parul@gmail.com', 'pp098', 3),
('siya', 's@gmail.com', '87sd4', 4),
('abhi', 'ab@gmail.com', 'atoz', 5),
('guest', 'guest@gmail.com', 'abcd', 6),
('Abcd', 'abcd@gmail.com', '12345', 7),
('nandini', 'nandini@gmail.com', 'nan123', 8),
('riya', 'riya@gmail.com', 'r123', 9);
