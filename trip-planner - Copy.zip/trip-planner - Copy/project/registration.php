<?php 
session_start();
header('location:logmain.php');
$con= mysqli_connect("localhost","root","");
mysqli_select_db($con,'tp');
$name= $_POST['name'];
$email= $_POST['email'];
$pass= $_POST['pass'];

$s="select * from user where email= '$email'";
$result=mysqli_query($con ,$s);
$num= mysqli_num_rows($result);

if($num == 1){
echo"Email already taken";
}
else
{
$reg="insert into user(name,email, pass) values('$name','$email','$pass')";
mysqli_query($con,$reg);
echo"Registration Successfull";
}
?>