
<?php 
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
    <style>


.container{

left:80%;
transform:translate(-50%,-50%);
position:absolute;

}
.fi{
font-size:16px;
background-color:#FFFFFF;
border-radius:10px;
box-shadow:5px 5px 10px black;
width:350px;
outline:none;
}
::-webkit-file-upload-button{
color:#FFFFFF;
background-color:#73aa27;
padding:10px;
border:none;
border-radius:10px;
box-shadow:1px 0 1px  1px #6b4559;
outline:none;
}
.btn{
background-color:#323f49;
text-transform:uppercase;
left:20%;
color:#FFFFFF;
}
input.btn:hover{
background-color:#000000;
color:#999999;

}
.i{
float:right;
margin-right:30px;
height:30px;
width:30px;
}
tabel{
tabel-layout:fixed;
}
.today{
background:#FFFF00;
}

.gallery {
		max-width:1060px;
		
		border-radius: 30px;
		margin: 0 auto;
		-moz-box-sizing: border-box;
		-webkit-box-sizing: border-box;
		box-sizing: border-box;
	}
	.image
	{
		width:180px;
		height:130px;
		margin:10px;
		box-shadow:0 0 20px 2px #334d4d;
		transition:1s;
	}
	
	.image:hover {
			transform:scale(1.4);
			z-index:1;	
				}
	.bg{
		text-color:#00ff00;
	}
.pp{
  position: absolute;
  top:45%;
  left:32%;
  font-size:35px;
  font-family:Arial;
}
.pr{
box-shadow: 1px 2px 10px 4px rgba(3, 10, 5, 2) ;

}
.pr:hover{
box-shadow: 1px 1px 6px 4px #000000;
}

.cont {
  position: relative;
  width:100%;
  max-width: 500px;
}



.overlay {
  position: absolute; 
  bottom:0;
  text-align:center; 
  background: rgb(0, 0, 0);
  background:#333333; /* Black see-through */
  color:#000000; 
  width:70%;
  height:100%;
  transition: .2s ease;
  opacity:0;
  font-family:Arial, Helvetica, sans-serif;
  color:black;
  font-size:16px;
  padding: 20px;
  text-align: center;
}

.cont:hover .overlay {
  opacity:0.9;
}

.se{
font-family:Arial, Helvetica, sans-serif;
font-size:30px;
color:#999999;

}
#tt{
width:50%;
margin-top:6%;
margin-left:25%;
}
.ho{
float:left;
height:84%;
width:26%;

background:#CCCCCC;
border:#CCCCCC solid;
}
.hp{
height:70%;
float:left;
margin-left:10%;
width:29%;
background:#CCCCCC;
border:#CCCCCC solid;
}
.hd{
height:84%;
float:right;

width:26%;
background:#CCCCCC;
border:#CCCCCC solid;
}

.im1{
padding:2%;
margin-left:35%;
margin-top:3%;

}
	</style>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>TRIPICA</title>
<!-- 
Moonlight Template 
http://www.templatemo.com/tm-512-moonlight
-->
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.png">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-theme.min.css">
        <link rel="stylesheet" href="css/fontAwesome.css">
        <link rel="stylesheet" href="css/light-box.css">
        <link rel="stylesheet" href="css/templatemo-main.css">

        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">

        <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
        
    </head>

<body>
    

    <div class="sequence">
   
      <div class="seq-preloader">

        <svg width="39" height="16" viewBox="0 0 39 16" xmlns="http://www.w3.org/2000/svg" class="seq-preload-indicator"><g fill="#F96D38"><path class="seq-preload-circle seq-preload-circle-1" d="M3.999 12.012c2.209 0 3.999-1.791 3.999-3.999s-1.79-3.999-3.999-3.999-3.999 1.791-3.999 3.999 1.79 3.999 3.999 3.999z"/><path class="seq-preload-circle seq-preload-circle-2" d="M15.996 13.468c3.018 0 5.465-2.447 5.465-5.466 0-3.018-2.447-5.465-5.465-5.465-3.019 0-5.466 2.447-5.466 5.465 0 3.019 2.447 5.466 5.466 5.466z"/><path class="seq-preload-circle seq-preload-circle-3" d="M31.322 15.334c4.049 0 7.332-3.282 7.332-7.332 0-4.049-3.282-7.332-7.332-7.332s-7.332 3.283-7.332 7.332c0 4.05 3.283 7.332 7.332 7.332z"/></g></svg>
      
      </div>
      
    </div>
       
        <nav>

          <div class="logo">
         <form method="post" action="home.php">
         <input type="image" name="im" src="logo/TRIPICA.png" height="60" width="220" >
         </form>
          <!--<img src="logo/TRIPICA.png" alt="Moon Light" height="60" width="220">-->
          </div>
          <div class="mini-logo">
              <img src="logo/t.png" alt="" height="60" width="60">
          </div>
          <ul>
            <li><a href="#1"><i class="fa fa-home"></i> <em>HOME</em></a></li>
            <li><a href="#2"><i class="fa fa-calendar-check-o"></i> <em>CALENDAR</em></a></li>
            <li><a href="#3"><i class="fa fa-suitcase"></i> <em>PACK MY BAG</em></a></li>
            <li><a href="#4"><i class="fa fa-id-card-o"></i> <em>MY DOCUMENTS</em></a></li>
            <li><a href="#5"><i class="fa fa-picture-o"></i> <em>MY GALLERY</em></a></li>
                           
               
           <!-- <li><a href="#7"><i class="fa fa-envelope"></i> <em>LOGOUT</em></a></li>-->
         <form method="post" action="logout.php">
         <input type="image" name="im" src="logo/exit.png" class="i" >
         </form>
          </ul>
               </div>                      
        </nav>

        <div class="slides">
          <div class="slide" id="1">
            <div class="content first-content">
              <div class="container-fluid">
                
                <!--1st page content -->
              <p style="font-size:28px; margin-left:25%; color:#009900;">  Tripica Welcomes you !</p>
                <br>
                <p>
                <aa style="font-size:38px;">F</aa>ounded in 2021, Tripica is India’s leading online holiday planner.Tripica has been loved from the users giving perfect services And it has been most visited website for trip planning .We provide tools for travel professionals to create experiences their customers love.

</p>
<p>&nbsp;&nbsp; &nbsp; &nbsp;The millionth itinerary is planned on Tripica. By the end of the year, Tripica welcomed its 100,000th user.</p><br><br>
<div class="ho"><img src="img/earth.png" class="im1" style="width:30%;"></img><br>
<p style="margin-left:17%; color:#006600; margin-top:6%;"><b>Available in 30+   countries </b></p>

</div>

<div class="hp"><img src="img/suitcase.png" class="im1" style="width:30%;"></img>
<p style="margin-left:7%; color:#006600; margin-top:2%;"><b>10,000+ people planned trips with Tripica </b></p>

</div>
<div class="hd"><img src="img/team.png" class="im1" style="width:35%;"></img>
<p style="margin-left:17%; color:#006600; margin-top:1%;"><b>Available in 30+ countries </b></p>

</div>
                </div>
            </div>
          </div>
          <div class="slide" id="2">
            <div class="content first-content" style="padding-top:1px;">
              <div class="container-fluid">
              <?php
function build_calendar($month, $year) {
    $mysqli = new mysqli('localhost', 'root', '', 'tp');
    $stmt = $mysqli->prepare("select * from bookings where MONTH(date) = ? AND YEAR(date) = ?");
    $stmt->bind_param('ss', $month, $year);
    $bookings = array();
    if($stmt->execute()){
        $result = $stmt->get_result();
        if($result->num_rows>0){
            while($row = $result->fetch_assoc()){
                $bookings[] = $row['date'];
            }
            
            $stmt->close();
        }
    }
    
    
     // Create array containing abbreviations of days of week.
     $daysOfWeek = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');

     // What is the first day of the month in question?
     $firstDayOfMonth = mktime(0,0,0,$month,1,$year);

     // How many days does this month contain?
     $numberDays = date('t',$firstDayOfMonth);

     // Retrieve some information about the first day of the
     // month in question.
     $dateComponents = getdate($firstDayOfMonth);

     // What is the name of the month in question?
     $monthName = $dateComponents['month'];

     // What is the index value (0-6) of the first day of the
     // month in question.
     $dayOfWeek = $dateComponents['wday'];

     // Create the table tag opener and day headers
     
    $datetoday = date('Y-m-d');
    
    
    
    $calendar = "<table class='table table-bordered'>";
    $calendar .= "<center><h4 style='color:#ffffff;'><b>$monthName $year</b></h4>";
    $calendar.= "<a class='btn btn-xs btn-primary' href='?month=".date('m', mktime(0, 0, 0, $month-1, 1, $year))."&year=".date('Y', mktime(0, 0, 0, $month-1, 1, $year)).'#2'."'>Previous Month</a> ";
    
    $calendar.= " <a class='btn btn-xs btn-primary' href='?month=".date('m')."&year=".date('Y').'#2'."'>Current Month</a> ";
    
    $calendar.= "<a class='btn btn-xs btn-primary' href='?month=".date('m', mktime(0, 0, 0, $month+1, 1, $year))."&year=".date('Y', mktime(0, 0, 0, $month+1, 1, $year)).'#2'."'>Next Month</a></center><br>";
    
    
        
      $calendar .= "<tr>";

     // Create the calendar headers

     foreach($daysOfWeek as $day) {
          $calendar .= "<th  class='header'>$day</th>";
     } 

     // Create the rest of the calendar

     // Initiate the day counter, starting with the 1st.

     $currentDay = 1;

     $calendar .= "</tr><tr>";

     // The variable $dayOfWeek is used to
     // ensure that the calendar
     // display consists of exactly 7 columns.

     if ($dayOfWeek > 0) { 
         for($k=0;$k<$dayOfWeek;$k++){
                $calendar .= "<td  class='empty'></td>"; 

         }
     }
    
     
     $month = str_pad($month, 2, "0", STR_PAD_LEFT);
  
     while ($currentDay <= $numberDays) {

          // Seventh column (Saturday) reached. Start a new row.

          if ($dayOfWeek == 7) {

               $dayOfWeek = 0;
               $calendar .= "</tr><tr>";

          }
          
          $currentDayRel = str_pad($currentDay, 2, "0", STR_PAD_LEFT);
          $date = "$year-$month-$currentDayRel";
          
            $dayname = strtolower(date('l', strtotime($date)));
            $eventNum = 0;
            $today = $date==date('Y-m-d')? "today" : "";
         /*if($date<date('Y-m-d')){
             $calendar.="<td><h4>$currentDay</h4> <button class='btn btn-danger btn-xs'>N/A</button>";
         }else*/if(in_array($date, $bookings)){
		
         $calendar.="<td class='$today'><h4>$currentDay &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; <img src='airplane.png' style='width:24%;'> </h4><button class='btn btn-primary btn-xs'>Leaving for trip</button>";
			 
         }
		 else{
             $calendar.="<td class='$today'><h4>$currentDay</h4> <a href='book.php?date=".$date."' class='btn btn-success btn-xs'>book</a>";
         }
            
            
           
            
          $calendar .="</td>";
          // Increment counters
 
          $currentDay++;
          $dayOfWeek++;

     }
     
     

     // Complete the row of the last week in month, if necessary

     if ($dayOfWeek != 7) { 
     
          $remainingDays = 7 - $dayOfWeek;
            for($l=0;$l<$remainingDays;$l++){
                $calendar .= "<td class='empty'></td>"; 

         }

     }
     
     $calendar .= "</tr>";

     $calendar .= "</table>";

     echo $calendar;

}
    
?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <style>
       @media only screen and (max-width: 760px),
        (min-device-width: 802px) and (max-device-width: 1020px) {

            /* Force table to not be like tables anymore */
            table, thead, tbody, th, td, tr {
                display: block;
				

            }
            
            

            .empty {
                display: none;
            }

            /* Hide table headers (but not display: none;, for accessibility) */
            th {
                position: absolute;
                top: -9px;
                left: -99px;
            }

            tr {
                border: 1px solid #ccc;
            }

            td {
                /* Behave  like a "row" */
                border: none;
                border-bottom: 1px solid #eee;
                position: relative;
				height:50%;	
                }



            /*
		Label the data
		*/
            td:nth-of-type(1):before {
                content: "Sunday";
            }
            td:nth-of-type(2):before {
                content: "Monday";
            }
            td:nth-of-type(3):before {
                content: "Tuesday";
            }
            td:nth-of-type(4):before {
                content: "Wednesday";
            }
            td:nth-of-type(5):before {
                content: "Thursday";
            }
            td:nth-of-type(6):before {
                content: "Friday";
            }
            td:nth-of-type(7):before {
                content: "Saturday";
            }


        }

        /* Smartphones (portrait and landscape) ----------- */

        @media only screen and (min-device-width: 320px) and (max-device-width: 480px) {
            body {
                padding: 0;
                margin: 0;
            }
        }

        /* iPads (portrait and landscape) ----------- */

        @media only screen and (min-device-width: 702px) and (max-device-width: 920px) {
            body {
                width: 500px;

            }
        }

        @media (min-width:540px) {
            table {
                table-layout: fixed;
				color:#FFFFFF;
            }
            td {
                width: 50%;
            }
        }
        
        .row{
            margin-top: 0;
        }
        
        .today{
            background:yellow;
			color:#666666;
        }
        
      
        
    </style>

 <!--   <div class="container">-->
        <div class="row">
            <div class="col-md-18">
                <?php
                     $dateComponents = getdate();
                     if(isset($_GET['month']) && isset($_GET['year'])){
                         $month = $_GET['month']; 			     
                         $year = $_GET['year'];
                     }else{
                         $month = $dateComponents['mon']; 			     
                         $year = $dateComponents['year'];
                     }
                    echo build_calendar($month,$year);
                ?>
            </div>
        </div>


              
              
              </div>
            </div>
          </div>
          <div class="slide" id="3">
            <div class="content second-content">
                <div class="container-fluid">
                  <br>
                  <pr class="se">  Select Type of Trip you are going on</pr>
                    <form action="trip.php" method="post"> <select name="trip-type" class="form-control" id="tt">
																			<option value="none" selected="" disabled="">Types of Trip</option>
																			<option value="so.php" >Solo-trip</option>
																			<option value="ca.php">Camping</option>
                                                                            <option value="ro.php">Road-trip</option>
																									                                                                            
																															</select></form>
              <img src="img/leaf (1).png" style="float:left; margin-top:24%; height:130px; width:130px;">     <img src="img/leaf1.png" style="float:right; margin-right:2%; margin-top:24%; transform:rotate(250deg); height:150px; width:150px;">                                                                                                </div>
            </div>
          </div>
          <div class="slide" id="4">
            <div class="content third-content">
                <div class="container-fluid">
                    <div class="col-md-12">
                        <div class="row">
                          
                     <h2>   Add your Documents here !</h2>
                     
                     <table style="margin-left:10%;">
                     <tr>
                     <th width="300">
                           <a href="adh.php">
                           <div class="cont"> 
                          <img src="img/adhar.png" style="width:70%;" height="130">
                          
                           <div class="overlay"><b style="color:#FFFFFF;">Add Your Adhar-Card here!</b><br><br>
                           <div class="pp" style="width:33%;">
                          <img  class="pr" src="logo/add.png" style="width:33%; height:33%;">
                          </div>
                           </div>
                           
                          </div>
                           </a> </th>
                           <br>
                       <th>    
                           <a href="dr.php">
                           <div class="cont"> 
                          <img src="img/dr.jfif" style="width:70%;" height="130">
                          
                           <div class="overlay"><b style="color:#FFFFFF;">Add Your Driving-License here!</b><br><br>
                           <div class="pp" style="width:33%;">
                          <img  class="pr" src="logo/add.png" style="width:37%; height:37%;">
                          </div>
                           </div>
                           
                          </div>
                    </a>
                    </th>
                    <br> 
                    <th>     
                          <a href="pas.php">
                           <div class="cont"> 
                          <img src="img/pa.jpg" style="width:70%;" height="130">
                          
                           <div class="overlay"><b style="color:#FFFFFF;">Add Your Passport here!</b><br><br>
                           <div class="pp" style="width:33%;">
                          <img  class="pr" src="logo/add.png" style="width:33%;">
                          </div>
                           </div>
                           
                          </div>
                           
                           </a> 
                           
                        </th></tr>
                        
                        <tr>
                        <th>
                        
                        </th>
                        <th style="padding-top:7%;">
                        <a href="oth.php">
                           <div class="cont"> 
                          <img src="img/folder.jpg" style="width:70%;" height="130">
                          
                           <div class="overlay"><b style="color:#FFFFFF;">Add Your other documents here!</b><br><br>
                           <div class="pp" style="width:33%;">
                          <img  class="pr" src="logo/add.png" style="width:33%;">
                          </div>
                           </div>
                           
                          </div>
                           
                           </a> 
                        </th></tr>
                        </table>   
                           
                            
                        </div>
                    </div>
                </div>
            </div>
          </div>
          
          
          
         
          
          
           
          <!-- MY GALLERY PART STARTS-->
          
          <div class="slide" id="5" >
           <div class="content second-content">
           <div class="left-content" style="text-align:center; ">     
                  
        
            <div class="main-btn"><a href="#6">Add images to Gallery</a></div><br>
           <?php include"db_conn.php";?>
          
    <?php
	$sql= "SELECT * from gallery ORDER BY galid DESC";
	$res = mysqli_query($conn, $sql);
	if(mysqli_num_rows($res) > 0)
	{
	?>
	
	     <ul class="gallery">
									 <li>
    
	<?php
		while($images = mysqli_fetch_assoc($res))
		{
		?>
      

         

<img class="image" src="uploads/<?php echo $images['gphoto'];  ?> ">

  
	<?php	}
	} 
	?>

           
      </li></ul>     
      </div>
           
                          
            </div></div> <!-- MY GALLERY PART ENDS -->
          
          <!-- Add images-->
         
<div class="slide" id="6">
           <div class="content second-content">
              <div class="container-fluid" style="
display:flex;


flex-direction:column;
min-height:100vh;
">
                  <div class="col-md-9"> 
             <div class="left-content">
             
             <?php if(isset($_GET['error'])): ?>
<p><?php echo $_GET['error']; ?></p>
<?php endif ?>
<form action="upload.php" method="post" enctype="multipart/form-data">
	<input type="file" name="my_image" class="fi"><br><br>
    <input type="submit" name="submit" value="upload" class="btn">
</form>
             
           </div></div></div>
          </div></div></div>
          
          
          
          <div class="slide" id="7">
           <div class="content second-content">
              <div class="container-fluid">
              
              </div></div></div>
          
          
          
          <div class="slide" id="#">
            <div class="content fifth-content">
                <div class="container-fluid">
                    <div class="col-md-6">
                        <div id="map">
     How to change your own map point
            1. Go to Google Maps
            2. Click on your location point
            3. Click "Share" and choose "Embed map" tab
            4. Copy only URL and paste it within the src="" field below
	>
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3647.3030413476204!2d100.5641230193719!3d13.757206847615207!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf51ce6427b7918fc!2sG+Tower!5e0!3m2!1sen!2sth!4v1510722015945" width="100%" height="500px" frameborder="0" style="border:0" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <form id="contact" action="" method="post">
                            <div class="row">
                                <div class="col-md-12">
                                  <fieldset>
                                    <input name="name" type="text" class="form-control" id="name" placeholder="Your name..." required="">
                                  </fieldset>
                                </div>
                                <div class="col-md-12">
                                  <fieldset>
                                    <input name="email" type="email" class="form-control" id="email" placeholder="Your email..." required="">
                                  </fieldset>
                                </div>
                                 <div class="col-md-12">
                                  <fieldset>
                                    <input name="subject" type="text" class="form-control" id="subject" placeholder="Subject..." required="">
                                  </fieldset>
                                </div>
                                <div class="col-md-12">
                                  <fieldset>
                                    <textarea name="message" rows="6" class="form-control" id="message" placeholder="Your message..." required=""></textarea>
                                  </fieldset>
                                </div>
                                <div class="col-md-12">
                                  <fieldset>
                                    <button type="submit" id="form-submit" class="btn">Send Now</button>
                                  </fieldset>
                                </div>
                            </div>
                        </form>
                        </div>

                </div>
            </div>
          </div>
       
        <div class="footer">
          <div class="content">
              
          </div>
        </div>
  <script type="text/javascript">
    var urlmenu = document.getElementById('tt');
    urlmenu.onchange = function() {
      window.location = this.options[this.selectedIndex].value;
    };
  </script>

  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

    <script src="js/vendor/bootstrap.min.js"></script>
    
    <script src="js/datepicker.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

    <script type="text/javascript">
    $(document).ready(function() {

        

        // navigation click actions 
        $('.scroll-link').on('click', function(event){
            event.preventDefault();
            var sectionID = $(this).attr("data-id");
            scrollToID('#' + sectionID, 750);
        });
        // scroll to top action
        $('.scroll-top').on('click', function(event) {
            event.preventDefault();
            $('html, body').animate({scrollTop:0}, 'slow');         
        });
        // mobile nav toggle
        $('#nav-toggle').on('click', function (event) {
            event.preventDefault();
            $('#main-nav').toggleClass("open");
        });
    });
    // scroll function
    function scrollToID(id, speed){
        var offSet = 0;
        var targetOffset = $(id).offset().top - offSet;
        var mainNav = $('#main-nav');
        $('html,body').animate({scrollTop:targetOffset}, speed);
        if (mainNav.hasClass("open")) {
            mainNav.css("height", "1px").removeClass("in").addClass("collapse");
            mainNav.removeClass("open");
        }
    }
    if (typeof console === "undefined") {
        console = {
            log: function() { }
        };
    }
	
    
    </script>
</body>
</html>