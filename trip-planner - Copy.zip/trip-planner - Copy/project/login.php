<?php 
session_start();

$con= mysqli_connect("localhost","root","");
mysqli_select_db($con,'tp');
$name= $_POST['name'];
$email= $_POST['email'];
$pass= $_POST['pass'];

$s="select * from user where email= '$email' && pass= '$pass'";
$result=mysqli_query($con ,$s);
$num= mysqli_num_rows($result);

if($num == 1){
	header('location:index.php');
}
else
{
 header('location:login.php');
}
?>