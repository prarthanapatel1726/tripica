<html>
<head>
<style>
body{
background-size: cover;
}
.co{

    position: relative;
    width: 100%;
    height: 84%;
  top:3%;
   overflow-y: scroll;
    background: rgba(0, 0, 0, 0.5);
	}
.he{	
       position: relative;
    width: 100%;
    height: 13%;
  
   top:1%;
    background: rgba(0, 0, 0, 0.5);
} 
.im{
float:left;
padding:1.1%;
height:68%;
width:18%;
}
.bt{
height:68%;
width:15%;
background-color:#FFFFFF;
font-size:14px;
font-stretch:narrower;
padding:0;
}
button{
float:left;
margin-top:1.1%;
}
.bt:hover{
background-color:#999999;
color:#FFFFFF;
}
.t{
font-size:30px;
font-family:Arial, Helvetica, sans-serif;
color:#CCCCCC;
}
.a{
color:#FFFFFF;
font-size:20px;
font-family:Arial, Helvetica, sans-serif;
margin-left:32%;
margin-bottom:7%;}
.ii{
margin-left:20%;
}
ul{
font-size:14px;
}
h{
font-size:30px;
text-transform:uppercase;
font-family:Arial, Helvetica, sans-serif;
}
.leftbox {
                float:left; 
             
	
                width:17%;
                height:340px;
            }
            .middlebox{
                float:left; 
				
                width:70%;
                height:340px;
            }
			.middlebox2{
                float:left; 
				
                width:80%;
                height:340px;
            }
			.column {
  float: left;
  width: 45%;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
.btn{
float:none;
height:20%;
width:20%;
font-size:16px;
background-color:#FFFFFF

}
.ot{
text-decoration:none;
color:#CCCCCC;
font-size:20px;
font-family:Arial, Helvetica, sans-serif;
float:right;
margin-right:3%;
margin-top:2%;
}
.ot:hover{
background:#666666;
height:30%;
text-align:center;
padding-top:0.5%;
width:10%;
}
    </style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body background="img/1.gif">
<div class="he">

<img src="logo/TRIPICA.png" class="im">
<a href="logmain.php">
<button class="bt"><i class="fa fa-home"></i>&nbsp;&nbsp;&nbsp;LOG-IN / SIGN-IN</button></a>
<a href="abt.php" class="ot">ABOUT US</a>
</div>
<div class="co"><br>
<center><p class="t">EASY TO USE, EASY TO PLAN.</p><BR>
<img src="logo/backpack.png"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;
<img src="logo/plane-ticket (1).png">
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
<img src="logo/gallery.png"></center>

<p class="a" style="display:inline-block; min-width:2.2cm; height:1cm; align: center;vertical-align: middle;">Pack your Bags &nbsp;

<img src="logo/right-arrow.png"  style="display:inline-block;vertical-align: middle;">&nbsp;Document holder 

<img src="logo/right-arrow.png"  style="display:inline-block;vertical-align: middle;"> Image gallery</p><hr style="width:90%; ">
<center><br>
<p class="t" >TRIP PLANNER BENEFITS</p></center>
<p><img src="img/2 (2).jpg" height="50%" width="30%" class="ii" style="display:inline-block; min-width:30%; height:50%; align: center;vertical-align: middle;"></img>
  <img src="logo/1.png" style="display:inline-block; vertical-align:top; margin-left:7%;"></img>
<h style="color:#ffffff; height="30%"">Start packing with tripica </h> 
</p>


<br><br><br>
<br><br><br>

  <div class="leftbox" >
  
 </div>
 <div class="middlebox" >
 <div class="row">
 <div class="column">
 <img src="logo/2.png" style="float:right;" ><br><br><br><br>
  <h style="color:#ffffff; left:30%; "><br>Documents Holder</h></div>
   <div class="column">
  <img src="img/3.jfif" class="ii" height="94%" width="95%" > 
</div>
</div>
<br><br><br><br><br><br>
<p><img src="img/4.jpg" height="70%" width="40%" class="ii" style="display:inline-block; min-width:40%; height:70%; align: center;vertical-align: middle; margin:20px;" ">
  <img src="logo/3.png" style="display:inline-block;vertical-align:top; margin-left:7%;">
<h style="color:#ffffff;">Image Gallery</h> 
</p>

<br><br><br>
 <center><a href="logmain.php"><button class="btn"><i class="fa fa-arrow-circle-right" aria-hidden="true"></i>&nbsp; &nbsp;START PLANNING</button></a></center>

<br><br><br>

</body>
</html>