<html>
<head>
<style>
body{
background-size: cover;
height:100%;
}
.co{

    position: relative;
    width: 70%;
    height: 80%;
	left:30%;
	top:-70%;  
   	
    background: rgba(0, 0, 0, 0.5);
	}
.he{	
       position: relative;
    width: 20%;
    height: 80%;
  left:-1%;
   top:10%;
    background: rgba(0, 0, 0, 0.5);
} 
.im{
float:left;
padding:1.1%;
height:68%;
width:18%;
}
.bt{
height:68%;
width:15%;
background-color:#FFFFFF;
font-size:14px;
font-stretch:narrower;
padding:0;
}
button{
float:left;
margin-top:1.1%;
}
.bt:hover{
background-color:#999999;
color:#FFFFFF;
}
a{

text-decoration:none;
padding:8%;
color:#ffffff;
font-style:normal;
font-family: "Open Sans", sans-serif;

}
a:hover{
background-color:#FFFFFF;
color:#000000;
}
.l{
padding-top:23%;

}
.u{
margin-top:-15%;
list-style-type:none;
}
.fi{
font-size:16px;
background-color:#FFFFFF;
border-radius:10px;
box-shadow:5px 5px 10px black;
width:350px;
margin-top:7%;
margin-left:7%;
outline:none;
}
::-webkit-file-upload-button{
color:#FFFFFF;
background-color:#73aa27;
padding:10px;
border:none;
border-radius:10px;
box-shadow:1px 0 1px  1px #6b4559;
outline:none;
}
.btn{
background-color:#323f49;
text-transform:uppercase;
margin-left:7%;

padding:1%;
border:#323f49 solid;
color:#FFFFFF;
border-radius:5px;
}

input.btn:hover{
background-color:#000000;
color:#999999;
border:#000000 solid;

}

.gallery {
		max-width:1060px;
		
		border-radius: 30px;
		margin-top:-20%;
		margin: 0 auto;
		-moz-box-sizing: border-box;
		-webkit-box-sizing: border-box;
		box-sizing: border-box;
	}
	.image
	{
		width:180px;
		height:130px;
		margin:10px;
		box-shadow:0 0 20px 2px #334d4d;
		transition:1s;
	}
	
	.image:hover {
			transform:scale(1.4);
			z-index:1;	
				}
				
input[type="checkbox"]
{
	width:20px;
	height:20px;
background-color:red;
}

.boxes {
  margin: auto;
  padding: 50px;
 
}

/*Checkboxes styles*/
input[type="checkbox"] { display: none; }

input[type="checkbox"] + label {
 
  position: relative;
  padding-left: 35px;
  margin-bottom: 20px;
  font: 14px/20px 'Open Sans', Arial, sans-serif;
  color: #ddd;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
}

input[type="checkbox"] + label:last-child { margin-bottom: 0; }

input[type="checkbox"] + label:before {
  content: '';
  display: block;
  width: 20px;
  height: 20px;
  border: 1px solid #6cc0e5;
  position: absolute;
  left: 0;
  top: 0;
  opacity: .6;
  -webkit-transition: all .12s, border-color .08s;
  transition: all .12s, border-color .08s;
}

input[type="checkbox"]:checked + label:before {
  width: 10px;
  top: -5px;
  left: 5px;
  border-radius: 0;
  opacity: 1;
  border-top-color: transparent;
  border-left-color: transparent;
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
}
.btn{
background-color:#336699;
text-transform:uppercase;
margin-left:20%;
color:#FFFFFF;
}
	
	
input.btn:hover{
background-color:#FFFFFF;
color:#666666;

}
.ro{
float:left;
width:70%;
}
.col{
border-left:#339999 solid;
float:left;
margin-top:-6%;
width:30%;

}

</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />

</head>
<body background="img/1.gif">
<div class="he">
		
         <form method="post" action="home.php"  class="form">
         <input type="image" name="im" src="logo/TRIPICA.png" height="60" width="220"  style="padding-top:18%; margin-left:14%;">
         </form>
       
		
        <ul class="u">
        	<li class="l"><a href="home.php"><i class="fa fa-home"></i>&nbsp;&nbsp; HOME</a></li>
            <li class="l"><a href="home.php#2"><i class="fa fa-calendar-check-o"></i>&nbsp;&nbsp; CALENDAR</a></li>
            <li class="l"><a href="home.php#3"><i class="fa fa-suitcase"></i>&nbsp;&nbsp; PACK MY BAG</a></li>
            <li class="l"><a href="home.php#4"><i class="fa fa-id-card-o"></i>&nbsp;&nbsp;MY DOCUMENTS</a></li>
            <li class="l"><a href="home.php#5"><i class="fa fa-picture-o"></i>&nbsp;&nbsp;MY GALLERY</a></li>
                           </ul>
               
          
         
</div>
<div class="co"><br>
<form action="" method="post">

	<div class="boxes"> <div class="ro">
    <h2 style="font:24px Open Sans, Arial, sans-serif; color:#58a39b; margin-top:-1%;">Select Necessary Things For Packing - Camping</h2>
    <br><br>
<input type="checkbox" name="thing[]" id="box-1" value="Sleeping Bag" <?php if(isset($_POST['thing']) && in_array("Sleeping Bag",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-1">Sleeping Bag</label>
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


<input type="checkbox" name="thing[]" id="box-2" value="Pillow" <?php if(isset($_POST['thing']) && in_array("Pillow",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-2">Pillow</label><br>
<br>

<input type="checkbox" name="thing[]" id="box-3" value="Portable Charger" <?php if(isset($_POST['thing']) && in_array("Portable Charger",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-3">Portable Charger </label>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<input type="checkbox" name="thing[]" id="box-4" value="Head Torch" <?php if(isset($_POST['thing']) && in_array("Head Torch",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-4">Head Torch</label><br>
<br>
<input type="checkbox" name="thing[]" id="box-5" value="WaterProof Jacket" <?php if(isset($_POST['thing']) && in_array("WaterProof Jacket",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-5">WaterProof Jacket</label>


&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<input type="checkbox" name="thing[]" id="box-6" value="Sunglass" <?php if(isset($_POST['thing']) && in_array("Sunglass",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-6">Sunglass</label><br>
<br>

<input type="checkbox" name="thing[]" id="box-7" value="Insect repellent" <?php if(isset($_POST['thing']) && in_array("Insect repellent",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-7">Insect repellent</label>


&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<input type="checkbox" name="thing[]" id="box-8" value="Match-Box" <?php if(isset($_POST['thing']) && in_array("Match-Box",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-8">Match-Box</label><br><br>

<input type="checkbox" name="thing[]" id="box-9" value="Stove" <?php if(isset($_POST['thing']) && in_array("Stove",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-9">Stove</label>


&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="thing[]" id="box-10" value="Dish Wash" <?php if(isset($_POST['thing']) && in_array("Dish Wash",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-10">Dish Wash</label><br><br>

<input type="checkbox" name="thing[]" id="box-11" value="Gloves" <?php if(isset($_POST['thing']) && in_array("Gloves",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-11">Gloves</label>



&nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="checkbox" name="thing[]" id="box-12" value="A Good Book" <?php if(isset($_POST['thing']) && in_array("A Good Book",$_POST['thing'])) echo 'checked="checked"';?>><label for="box-12">A good book</label><br><br>
<br><br>

<input type="submit" name="submit" value="submit" class="btn"> 
</form><img src="img/tent.png" width="100" height="100" style="float:left; margin-top:5%;""></div></div>

<div class="col">
<?php
if(isset($_POST["submit"]))
{
	echo '<h3 style="font:24px Open Sans, Arial, sans-serif; color:#58a39b; margin-top:-5%;margin-left:10%;"> Already packed items</h3>';
	foreach($_POST["thing"] as $thing)
	{
		echo '<p style="font:14px/20px Open Sans, Arial, sans-serif;
    color: #ddd;margin-left:10%;">'.$thing.'</p>';
	}
}
else
{
	echo '<p style="font:24px Open Sans, Arial, sans-serif;
    color: #ddd;margin-left:10%; margin-top:2%;">Please select any items</p>';
} 
?>
</div></div>
</body>
</html>