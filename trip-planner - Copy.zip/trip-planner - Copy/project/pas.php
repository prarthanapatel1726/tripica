<html>
<head>
<style>
body{
background-size: cover;
height:100%;
}
.co{

    position: relative;
    width: 70%;
    height: 80%;
	left:30%;
	top:-70%;  
   	
    background: rgba(0, 0, 0, 0.5);
	}
.he{	
       position: relative;
    width: 20%;
    height: 80%;
  left:-1%;
   top:10%;
    background: rgba(0, 0, 0, 0.5);
} 
.im{
float:left;
padding:1.1%;
height:68%;
width:18%;
}
.bt{
height:68%;
width:15%;
background-color:#FFFFFF;
font-size:14px;
font-stretch:narrower;
padding:0;
}
button{
float:left;
margin-top:1.1%;
}
.bt:hover{
background-color:#999999;
color:#FFFFFF;
}
a{

text-decoration:none;
padding:8%;
color:#ffffff;
font-style:normal;
font-family: "Open Sans", sans-serif;

}
a:hover{
background-color:#FFFFFF;
color:#000000;
}
.l{
padding-top:23%;

}
.u{
margin-top:-15%;
list-style-type:none;
}
.fi{
font-size:16px;
background-color:#FFFFFF;
border-radius:10px;
box-shadow:5px 5px 10px black;
width:350px;
margin-top:7%;
margin-left:7%;
outline:none;
}
::-webkit-file-upload-button{
color:#FFFFFF;
background-color:#73aa27;
padding:10px;
border:none;
border-radius:10px;
box-shadow:1px 0 1px  1px #6b4559;
outline:none;
}
.btn{
background-color:#323f49;
text-transform:uppercase;
margin-left:7%;

padding:1%;
border:#323f49 solid;
color:#FFFFFF;
border-radius:5px;
}

input.btn:hover{
background-color:#000000;
color:#999999;
border:#000000 solid;

}

.gallery {
		max-width:1060px;
		
		border-radius: 30px;
		margin-top:-20%;
		margin: 0 auto;
		-moz-box-sizing: border-box;
		-webkit-box-sizing: border-box;
		box-sizing: border-box;
	}
	.image
	{
		width:180px;
		height:130px;
		margin:10px;
		box-shadow:0 0 20px 2px #334d4d;
		transition:1s;
	}
	
	.image:hover {
			transform:scale(1.4);
			z-index:1;	
				}
	
    </style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body background="img/1.gif">
<div class="he">
		
         <form method="post" action="home.php">
         <input type="image" name="im" src="logo/TRIPICA.png" height="60" width="220"  style="padding-top:18%; margin-left:14%;">
         </form>
       
		
        <ul class="u">
        	<li class="l"><a href="home.php"><i class="fa fa-home"></i>&nbsp;&nbsp; HOME</a></li>
            <li class="l"><a href="home.php#2"><i class="fa fa-calendar-check-o"></i>&nbsp;&nbsp; CALENDAR</a></li>
            <li class="l"><a href="home.php#3"><i class="fa fa-suitcase"></i>&nbsp;&nbsp; PACK MY BAG</a></li>
            <li class="l"><a href="home.php#4"><i class="fa fa-id-card-o"></i>&nbsp;&nbsp;MY DOCUMENTS</a></li>
            <li class="l"><a href="home.php#5"><i class="fa fa-picture-o"></i>&nbsp;&nbsp;MY GALLERY</a></li>
                           </ul>
               
          
         
</div>
<div class="co"><br>

 <?php if(isset($_GET['error'])): ?>
<p><?php echo $_GET['error']; ?></p>
<?php endif ?>
<form action="upload3.php" method="post" enctype="multipart/form-data">
	<input type="file" name="my_image" class="fi"><br><br>
    <input type="submit" name="submit" value="upload" class="btn">
</form><br>
<?php include"db_conn.php";?>
          
    <?php
	$sql= "SELECT * from pas ORDER BY pid DESC";
	$res = mysqli_query($conn, $sql);
	if(mysqli_num_rows($res) > 0)
	{
	?>
	
	     <ul class="gallery">
									 <li >
    
	<?php
		while($images = mysqli_fetch_assoc($res))
		{
		?>
      

         

<img class="image" src="uploads/<?php echo $images['gphoto'];  ?> ">

  
	<?php	}
	} 
	?>

           
      </li></ul>     
</div>
</body>
</html>