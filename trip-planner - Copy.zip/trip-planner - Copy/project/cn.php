<?php 
/*
$link = mysql_connect("localhost", "root", "")

        or die("Could not connect");

$db = mysql_select_db("phpdbadmin", $link)
		or die("Could not select database");
*/		
// establishing the MySQLi connection
$link = mysqli_connect("localhost","root","","tp");
if (mysqli_connect_errno())
{
echo "MySQLi Connection was not established: " . mysqli_connect_error();
} 
?>